﻿using System;
using UnityEngine;

namespace InternalRealtimeCSG
{
	
#if UNITY_EDITOR
	public enum PrefabInstantiateBehaviour
	{
		Reference,
		Copy
	}

#endif
}
